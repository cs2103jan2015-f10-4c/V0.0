

#include "UI.h"

using  namespace std;

int main(){

	UI prototype;
	prototype.main();

	return 0;
}