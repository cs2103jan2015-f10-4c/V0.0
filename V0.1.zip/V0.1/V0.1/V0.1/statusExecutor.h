
#ifndef STATUSEXECUTOR_H
#define STATUSEXECUTOR_H
#include "Task.h"
#include <vector>

class statusExecutor{

private:

    
	]


public:

	void completeTask(int);
	void incompleteTask(int);


};


#endif